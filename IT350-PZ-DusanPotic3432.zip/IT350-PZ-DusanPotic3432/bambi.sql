/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     1/24/2019 3:30:30 PM                         */
/*==============================================================*/


drop table if exists KAPACITET;

drop table if exists NARUCENI_PROIZVODI;

drop table if exists NARUDZBENICA;

drop table if exists NARUDZBENICE_PJ;

drop table if exists PJ;

drop table if exists PROIZVOD;

drop table if exists PROIZVODNJA;

drop table if exists SKLADISTE;

drop table if exists SKLADISTE_PROIZVODA;

drop table if exists VRSTA;

/*==============================================================*/
/* Table: KAPACITET                                             */
/*==============================================================*/
create table KAPACITET
(
   KAPACITET_ID         int not null auto_increment,
   MIN_KAPACITET        int not null,
   MAX_KAPACITET        int not null,
   UK_KAPACITET         int not null,
   primary key (KAPACITET_ID)
);

/*==============================================================*/
/* Table: NARUCENI_PROIZVODI                                    */
/*==============================================================*/
create table NARUCENI_PROIZVODI
(
   PROIZVOD_ID          int not null,
   NARUDZBENICA_ID      int not null,
   TRAZENA_KOLICINA     int not null,
   primary key (PROIZVOD_ID, NARUDZBENICA_ID)
);

/*==============================================================*/
/* Table: NARUDZBENICA                                          */
/*==============================================================*/
create table NARUDZBENICA
(
   NARUDZBENICA_ID      int not null auto_increment,
   SKLADISTE_ID         int not null,
   DATUM_SLANJA         date not null,
   primary key (NARUDZBENICA_ID)
);

/*==============================================================*/
/* Table: NARUDZBENICE_PJ                                       */
/*==============================================================*/
create table NARUDZBENICE_PJ
(
   NARUDZBENICA_ID      int not null,
   PJ_ID                int not null,
   primary key (NARUDZBENICA_ID, PJ_ID)
);

/*==============================================================*/
/* Table: PJ                                                    */
/*==============================================================*/
create table PJ
(
   PJ_ID                int not null auto_increment,
   KAPACITET_ID         int not null,
   IME                  varchar(50) not null,
   MESTO                varchar(50) not null,
   primary key (PJ_ID)
);

/*==============================================================*/
/* Table: PROIZVOD                                              */
/*==============================================================*/
create table PROIZVOD
(
   PROIZVOD_ID          int not null auto_increment,
   VRSTA_ID             int not null,
   NAZIV                varchar(50) not null,
   JEDINICA_MERE        int not null,
   CENA                 decimal(7,2) not null,
   primary key (PROIZVOD_ID)
);

/*==============================================================*/
/* Table: PROIZVODNJA                                           */
/*==============================================================*/
create table PROIZVODNJA
(
   PROIZVOD_ID          int not null,
   PJ_ID                int not null,
   primary key (PROIZVOD_ID, PJ_ID)
);

/*==============================================================*/
/* Table: SKLADISTE                                             */
/*==============================================================*/
create table SKLADISTE
(
   SKLADISTE_ID         int not null auto_increment,
   NAZIV                varchar(50) not null,
   MESTO                varchar(50) not null,
   UK_KAPACITET_ZALIHA  int not null,
   primary key (SKLADISTE_ID)
);

/*==============================================================*/
/* Table: SKLADISTE_PROIZVODA                                   */
/*==============================================================*/
create table SKLADISTE_PROIZVODA
(
   PROIZVOD_ID          int not null,
   SKLADISTE_ID         int not null,
   TRENUTNA_KOLICINA    int not null,
   primary key (PROIZVOD_ID, SKLADISTE_ID)
);

/*==============================================================*/
/* Table: VRSTA                                                 */
/*==============================================================*/
create table VRSTA
(
   VRSTA_ID             int not null auto_increment,
   NAZIV                varchar(50) not null,
   primary key (VRSTA_ID)
);

INSERT INTO KAPACITET (KAPACITET_ID, MIN_KAPACITET, MAX_KAPACITET, UK_KAPACITET) VALUES
(1, 2000, 30000, 37000),
(2, 2300, 33000, 34000),
(3, 3600, 32000, 33000),
(4, 1700, 28000, 33000),
(5, 2000, 17000, 19000),
(6, 4000, 10000, 12000);

INSERT INTO PJ (PJ_ID, KAPACITET_ID, IME, MESTO) VALUES
(1, 1, 'Jedinica za Plazmu', 'Pozarevac'),
(2, 2, 'Jedinica za Wellness', 'Pozarevac'),
(3, 3, 'Jedinica za Bambi Biskvite', 'Pozarevac'),
(4, 4, 'Jedinica za Josh!', 'Beograd'),
(5, 5, 'Jedinica za Zlatni Pek', 'Beograd'),
(6, 6, 'Jedinica za Bambi Napolitanke', 'Nis');

INSERT INTO VRSTA (VRSTA_ID, NAZIV) VALUES
(1, 'Gotov proizvod'),
(2, 'Polugotov proizvod'),
(3, 'Poluproizvod');

INSERT INTO PROIZVOD (VRSTA_ID, NAZIV, JEDINICA_MERE, CENA) VALUES
(1, 'Plazma', 150, 109.99),
(1, 'WELLNESS', 150, 79.99),
(1, 'Bambi Biskviti', 110, 66.99),
(1, 'Josh!', 130, 54.99),
(1, 'Zlatni Pek', 100, 39.99),
(1, 'Bambi Napolitanke', 150, 69.99);

INSERT INTO SKLADISTE (SKLADISTE_ID, NAZIV, MESTO, UK_KAPACITET_ZALIHA) VALUES
(1, 'Skladiste 01', 'Zona 01', 23000),
(2, 'Skladiste 02', 'Zona 02', 24000),
(3, 'Skladiste 03', 'Zona 02', 14000);

INSERT INTO NARUDZBENICA (NARUDZBENICA_ID, SKLADISTE_ID, DATUM_SLANJA) VALUES 
(1, 2, '2018-01-01'),
(2, 1, '2018-12-10'),
(3, 1, '2018-12-10');

INSERT INTO PROIZVODNJA (PROIZVOD_ID, PJ_ID) VALUES
(1,1),
(2,2),
(3,3),
(4,4),
(5,5),
(6,6);

INSERT INTO SKLADISTE_PROIZVODA (PROIZVOD_ID, SKLADISTE_ID, TRENUTNA_KOLICINA) VALUES
(1, 1, 14000),
(2, 1, 500),
(3, 1, 1000),
(4, 1, 2000),
(1, 2, 300),
(2, 2, 14000),
(3, 2, 429),
(4, 2, 500),
(1, 3, 300),
(3, 3, 429),
(4, 3, 500);

INSERT INTO NARUDZBENICE_PJ (NARUDZBENICA_ID, PJ_ID) VALUES
(1, 1),
(2, 2),
(3, 1);

INSERT INTO NARUCENI_PROIZVODI (PROIZVOD_ID, NARUDZBENICA_ID, TRAZENA_KOLICINA) VALUES
(1, 1, 1000),
(2, 1, 200),
(3, 1, 50),
(4, 2, 1000),
(1, 3, 7200);


alter table NARUCENI_PROIZVODI add constraint FK_NARUCENI_PROIZVODI foreign key (PROIZVOD_ID)
      references PROIZVOD (PROIZVOD_ID) on delete restrict on update restrict;

alter table NARUCENI_PROIZVODI add constraint FK_NARUCENI_PROIZVODI2 foreign key (NARUDZBENICA_ID)
      references NARUDZBENICA (NARUDZBENICA_ID) on delete restrict on update restrict;

alter table NARUDZBENICA add constraint FK_PORUCIVANJE foreign key (SKLADISTE_ID)
      references SKLADISTE (SKLADISTE_ID) on delete restrict on update restrict;

alter table NARUDZBENICE_PJ add constraint FK_NARUDZBENICE_PJ foreign key (NARUDZBENICA_ID)
      references NARUDZBENICA (NARUDZBENICA_ID) on delete restrict on update restrict;

alter table NARUDZBENICE_PJ add constraint FK_NARUDZBENICE_PJ2 foreign key (PJ_ID)
      references PJ (PJ_ID) on delete restrict on update restrict;

alter table PJ add constraint FK_KAPACITET_PJ foreign key (KAPACITET_ID)
      references KAPACITET (KAPACITET_ID) on delete restrict on update restrict;

alter table PROIZVOD add constraint FK_VRSTA_PROIZVODA foreign key (VRSTA_ID)
      references VRSTA (VRSTA_ID) on delete restrict on update restrict;

alter table PROIZVODNJA add constraint FK_PROIZVODNJA foreign key (PROIZVOD_ID)
      references PROIZVOD (PROIZVOD_ID) on delete restrict on update restrict;

alter table PROIZVODNJA add constraint FK_PROIZVODNJA2 foreign key (PJ_ID)
      references PJ (PJ_ID) on delete restrict on update restrict;

alter table SKLADISTE_PROIZVODA add constraint FK_SKLADISTE_PROIZVODA foreign key (PROIZVOD_ID)
      references PROIZVOD (PROIZVOD_ID) on delete restrict on update restrict;

alter table SKLADISTE_PROIZVODA add constraint FK_SKLADISTE_PROIZVODA2 foreign key (SKLADISTE_ID)
      references SKLADISTE (SKLADISTE_ID) on delete restrict on update restrict;
	  
	  




