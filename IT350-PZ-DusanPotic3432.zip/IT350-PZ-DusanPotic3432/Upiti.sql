
-- a)

SELECT pj.ime, pj.mesto, SUM(proizvod.cena * skladisti_proizvode.trenutna_kolicina) as ukupna_cena
FROM pj, lista_proizvoda, proizvod, skladisti_proizvode
WHERE pj.pj_id = lista_proizvoda.pj_id
AND proizvod.proizvod_id = lista_proizvoda.proizvod_id
AND skladisti_proizvode.proizvod_id = lista_proizvoda.proizvod_id
GROUP BY pj.pj_id;

-- b)

SELECT s.*,broj_razlicitih
FROM skladiste AS s
INNER JOIN
    (SELECT skladiste_id, COUNT(DISTINCT proizvod_id) AS counts, MAX(DISTINCT proizvod_id) as broj_razlicitih
    FROM skladisti_proizvode
    GROUP BY skladiste_id) AS tabela 
ON s.skladiste_id = tabela.skladiste_id
and tabela.counts = tabela.broj_razlicitih;

-- c)

SELECT pj.ime, a.datum_slanja, skladiste.skladiste_id
FROM pj,narudzbenica AS a,skladiste, lista_narudzbenica
WHERE lista_narudzbenica.pj_id = pj.pj_id 
AND lista_narudzbenica.narudzbenica_id = a.narudzbenica_id
AND a.skladiste_id= skladiste.skladiste_id
AND a.datum_slanja = (
	SELECT max(b.datum_slanja)
	FROM narudzbenica AS b) 
ORDER BY a.narudzbenica_id DESC limit 1;
	
-- d)

SELECT proizvod.naziv, proizvod.cena
FROM proizvod, lista_proizvoda
GROUP BY proizvod.proizvod_id
ORDER BY proizvod.cena DESC;

-- e)

SELECT n.datum_slanja, proizvod.naziv, porudzbenice.trazena_kolicina
FROM narudzbenica AS n, proizvod, porudzbenice
WHERE porudzbenice.proizvod_id = proizvod.proizvod_id
AND porudzbenice.narudzbenica_id = n.narudzbenica_id
AND porudzbenice.trazena_kolicina * proizvod.jedinica_mere > 100000
GROUP BY n.datum_slanja, proizvod.naziv
ORDER BY n.datum_slanja;

-- f)
	
SELECT narudzbenica.narudzbenica_id, narudzbenica.skladiste_id, narudzbenica.datum_slanja
FROM(	
	SELECT tabela.s_id AS id, MAX(tabela.suma) AS maksimum
	FROM (SELECT SKLADISTE.SKLADISTE_ID AS s_id, SUM(skladisti_proizvode.trenutna_kolicina) AS suma
		FROM skladiste, skladisti_proizvode
		WHERE skladisti_proizvode.skladiste_id = skladiste.skladiste_id
		GROUP BY S_id
		) AS tabela
	)AS tabela2, narudzbenica
WHERE narudzbenica.skladiste_id= tabela2.id
AND narudzbenica.datum_slanja BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) AND CURRENT_DATE();	
	
	
	
	
	
	